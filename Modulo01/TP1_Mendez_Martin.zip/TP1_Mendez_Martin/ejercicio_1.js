document.writeln("Hola Mundo!");
//Muestra el mensaje "Hola mundo!" en el frontend 