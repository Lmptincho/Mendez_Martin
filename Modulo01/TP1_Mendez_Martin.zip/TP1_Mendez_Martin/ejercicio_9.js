//Crear el archivo “ejercicio_9.js”. Declarar un array llamado “vocales” con las 5 letras. Luego se
//deben imprimir en el navegador uno debajo de otro

let vocales = `a <br/> e <br/> i <br/> o <br/> u`
document.write(vocales)