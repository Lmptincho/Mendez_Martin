//Crear un array llamado “dias” y que almacene el nombre de los siete días de la semana. Mostrar por
//pantalla los siete nombres utilizando la función console.log()


/*let dias = ["Lunes", "<br>", "Martes","<br>", "Miercoles","<br>", "Jueves","<br>", "Viernes","<br>", "Sabado","<br>", "Domigo pa","<br>",]
console.log(dias)
document.write(dias)
const fecha = new Date();
document.write("Profe le dejo la fecha por si se le olvido corrigiendo los tp", "<br>", fecha)*/


//En el intento de arriba me mostraba las "," y no me gusto, por eso depure el codigo y utilice la funcion de las ``

let dias = [`Lunes <br> Martes <br> Miercoles <br> Jueves <br> Viernes <br> Sabado <br> Domigo pa <br>`]
console.log(dias)
document.write(dias)
const fecha = new Date();
document.write("Profe le dejo la fecha por si se le olvido corrigiendo los tp", "<br>", fecha)