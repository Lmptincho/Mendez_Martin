let dato, resultado;  //define las variables "dato" y "resultado"
val1 = window.prompt("Introduce tu nombre", "..."); // carga la variable "val1" con el nombre del usuario
val2 = window.prompt("Introduce tu apellido", "..."); // carga la variable "val2" con el apellido del usuario
resultado = `Concatenado tu nombre y apellido es: ${val1} ${val2} `; // concatena el nombre y el apellido con la funcion `${val1}, ${val2}` 
document.write(resultado);   //muestra el resultado por pantalla     // para hacer mas efectivo el codigo 